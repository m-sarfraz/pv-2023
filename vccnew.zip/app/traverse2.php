<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class traverse2 extends Model
{
    protected $table = 'taverse2';
}
