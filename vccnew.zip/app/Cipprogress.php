<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cipprogress extends Model
{
    protected $table = 'cip_progress';
}
