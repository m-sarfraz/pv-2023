<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class jdlSheet extends Model
{
    protected $table = 'jdl';
}
