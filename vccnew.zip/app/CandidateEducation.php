<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateEducation extends Model
{
    //
    protected $table = 'candidate_educations';
}
