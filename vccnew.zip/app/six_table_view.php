<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class six_table_view extends Model
{
    protected $table = 'six_table_view';
}
