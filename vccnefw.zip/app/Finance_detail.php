<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Finance_detail extends Model
{
    protected $table = 'finance_detail';
    
}
