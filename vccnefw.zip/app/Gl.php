<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gl extends Model
{
    protected $table = 'gl';
}
